close all
clear,clc
 
addpath('F:\﮵������')
load('data.2.mat')
addpath('F:\������ѵ��\RBFѵ������')
load('M73.mat')

Tfinal1=length(I.data);
bias=0;   
x1=V.data(1:2:Tfinal1)'; 
x2=SOC.data(1:2:Tfinal1)'; 
x3=I.data(1:2:Tfinal1)'+bias; 
Tfinal2=length(x1);
x1=x1(1:Tfinal2-1);
x2=x2(2:Tfinal2);
x3=x3(2:Tfinal2)+bias;
V_0=x1(1);SOC_0=x2(1); 

figure(1)
subplot(311)
plot(x1)
subplot(312)
plot(x2)
subplot(313)
plot(x3)

n=2;            %number of state
q=0.001;    
r=0.1;  
Q=q^2*eye(n); 
R=r^2;

w0=2.4195;sigma=0.8326;M=73; 
t_sample=2;Cn=3.45*3600; 
F=@(X,u,i)wi(i)*exp(-(sigma*norm([X;u]-ti(i,:)'))^2);
h=@(X,u)w0;
for i=1:M
    h=@(X,u)h(X,u)+F(X,u,i);
end
f=@(X,u)[h(X,u);X(2)-u*t_sample/Cn];
s=[V_0;SOC_0]; % initial state
x=0.9*s; % initial state with noise
P = 1*eye(n);                              
N=Tfinal2-2;                                    
xV = zeros(n,N);   %estmate       
sV = zeros(n,N);   %actual state       
zV = zeros(1,N);

for k=1:N
    u=x3(k);
    z = h(s,u);     % model output measurments  
    sV(:,k)= s;                   % save actual state         
    zV(k)  = z;                   % save measurment   
    [x, P, K] = ukf_sunli(f,x,P,h,z,Q,R,u);           
    xV(:,k) = x;                  % save estimate         
    %    s = f(s,u)+q*randn(2,1);
    s = f(s,u);                 % state update process
   
end

% plot results
figure(2)
subplot(211)
%plot(1:N, sV(2,:), '-', 1:N, xV(2,:), '--',1:N+1,x2,'k')
%legend('RBFNN Model output','UKF estimation','Measurements')
%figure(2)
plot(1:N, xV(2,:), '--',1:N+1,x2,'k')
legend('original RBFNN-UKF estimation','actual SOC')
xlabel('Time(s)')
ylabel('SOC')
title('SOC(0)=68.1%')
hold on

figure(3)
subplot(2,1,1)
plot(1:N+1,x3,'k:',1:N+1,x3-bias,'b-')

figure(4)
plot( xV(2,:)-x2(1:length(x2)-1))
legend('SOC error')






















































