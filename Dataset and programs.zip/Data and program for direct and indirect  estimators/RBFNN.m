clear, clc
clear global
close all

addpath('F:\﮵������')
for i=1:14
 eval(['load data.',int2str(i),'.mat']) 
 Tfinal=length(I.data);
 x1=SOC.data(1:2:Tfinal)';   
 x2=I.data(1:2:Tfinal)'; 
 x3=V.data(1:2:Tfinal)';
 P=[x3(1:end-1);x1(2:end);x2(2:end)];   
 T=x3(2:end);
 PP{i}=P;
 TT{i}=T;
end

P_train=[PP{1},PP{2},PP{7},PP{8},PP{9},PP{11},PP{12}];
T_train=[TT{1},TT{2},TT{7},TT{8},TT{9},TT{11},TT{12}]; 
P_test=[PP{6}];
T_test=[TT{6}]; 

net=newrb(P_train,T_train,0.0004);
view(net)
y=sim(net,P_train);

t_T_train=[1:1:length(T_train)];
figure(1)
plot(t_T_train,T_train,'r')
t_y=[1:1:length(y)];
figure(1)
hold on
plot(t_y,y,'k')
legend('actual Voltage','RBFNN output');

y1=sim(net,P_test);

t_T_test=[1:1:length(T_test)];
figure(2)
plot(t_T_test,T_test,'r')
t_y1=[1:1:length(y1)];
figure(2)
hold on
plot(t_y1,y1,'k')
legend('actual Voltage','RBFNN output');

ti=net.Iw{1};
wi=net.Lw{2};
sigma=net.b{1};
w0=net.b{2};
