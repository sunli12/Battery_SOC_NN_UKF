clear, clc
clear global
close all

addpath('F:\﮵�ز���')
for i=1:27
 eval(['load data',int2str(i),'.mat']) 
 Tfinal=length(I.data);
 x1=SOC.data(1:Tfinal)';   
 x2=I.data(1:Tfinal)'; 
 x3=V.data(1:Tfinal)';
 P=[x2;x3];   
 T=x1;
 PP{i}=P;
 TT{i}=T;
end


P_train=[PP{1},PP{5},PP{10}];
T_train=[TT{1},TT{5},TT{10}];   % Training data
P_test=[PP{25}];
T_test=[TT{25}];  %Testing data

setdemorandstream(pi)
X = tonndata(P_train,true,false);
T = tonndata(T_train,true,false);
trainFcn = 'trainlm';
inputDelays = 1:2;
feedbackDelays = 1:2;
hiddenLayerSize = 17;
net = narxnet(inputDelays,feedbackDelays,hiddenLayerSize,'open',trainFcn);
[x,xi,ai,t] = preparets(net,X,{},T);
[net,tr] = train(net,x,t,xi,ai);
y = net(x,xi,ai);
e = gsubtract(t,y);
performance = perform(net,t,y)
view(net)

T1=cell2mat(T);
y1=cell2mat(y);
t_T1=[1:1:length(T1)];
figure(1)
plot(t_T1,T1,'r')
t_y1=[1:1:length(y1)];
figure(1)
hold on
plot(t_y1,y1,'k')
legend('actual SOC','NARX-NN output');


%  Testing for NARX-NN
X_test = tonndata(P_test,true,false);  
T_test = tonndata(T_test,true,false);
[x,xi,ai,t] = preparets(net,X_test,{},T_test);
y_test = net(x,xi,ai);
e = gsubtract(t,y_test);
performance = perform(net,t,y_test)
T2=cell2mat(T_test );
y2=cell2mat(y_test);
t_T2=[1:1:length(T2)];
figure(2)
plot(t_T2,T2,'r')
t_y2=[1:1:length(y2)];
figure(2)
hold on
plot(t_y2,y2,'k')
legend('actual SOC','NARX-NN output');