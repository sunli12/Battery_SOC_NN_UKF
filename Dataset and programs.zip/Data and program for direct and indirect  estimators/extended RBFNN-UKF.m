close all
clear,clc

addpath('F:\﮵������')
load('data.1.mat')
addpath('F:\������ѵ��\RBFѵ������')
load('M73.mat')

Tfinal1=length(I.data);
bias=0.1;
x1=V.data(1:2:Tfinal1)';
x2=SOC.data(1:2:Tfinal1)'; 
x3=I.data(1:2:Tfinal1)';
Tfinal2=length(x1);
x1=x1(1:Tfinal2-1);
x2=x2(2:Tfinal2);
x3=x3(2:Tfinal2)+bias;
V_0=x1(1);SOC_0=x2(1);I_bias_0=0.1;

figure(1)
subplot(311)
plot(x1)
subplot(312)
plot(x2)
subplot(313)
plot(x3)

n=3;            %number of state
q=0.001;    
r=0.1;  
Q=q^2*eye(n);
R=r^2;

w0=2.4195;sigma=0.8326;M=73; 
t_sample=2;Cn=3.45*3600; 
F=@(X,u,i)wi(i)*exp(-(sigma*norm([X(1),X(2),u-X(3)]-ti(i,:)))^2);
g=@(X,u)w0;
for i=1:M
    g=@(X,u)g(X,u)+F(X,u,i);
end
f=@(X,u)[g(X,u);X(2)-(u-X(3))*t_sample/Cn;X(3)];
h=g;

s=[V_0;SOC_0;I_bias_0]; % initial state
x=0.9*s; % initial state with noise
P = 1*eye(n);                              
N=Tfinal2-2;                                    
xV = zeros(n,N);   %estmate       
sV = zeros(n,N);   %actual state       
zV = zeros(1,N);

for k=1:N
    u=x3(k);
    z = h(s,u);     % model output measurments  
    sV(:,k)= s;                   % save actual state         
    zV(k)  = z;                   % save measurment   
    [x, P, K] = ukf_sunli(f,x,P,h,z,Q,R,u);           
    xV(:,k) = x;                  % save estimate         
    %    s = f(s,u)+q*randn(2,1);
    s = f(s,u);                 % state update process
end

% plot results
figure(2)
subplot(2,1,1)
%plot(1:N, sV(2,:), '-', 1:N, xV(2,:), '--',1:N+1,x2,'k')
%legend('RBFNN Model SOC output','UKF SOC estimation','actual SOC')
plot(1:N, xV(2,:), '--',1:N+1,x2,'k')
legend('extended RBFNN-UKF estimation','actual SOC')
subplot(2,1,2)
plot(1:N, xV(3,:), '--',[1,N],[bias,bias],'k')
legend('extended RBFNN-UKF estimation','actual bias')

figure(3)
subplot(2,1,1)
plot( xV(2,:)-x2(1:length(x2)-1))
legend('SOC error')
subplot(2,1,2)
plot( xV(3,:)-bias)
legend('I bias error')